import psycopg2
import json
from flask import Flask, request, send_from_directory

tables = {'gas': {'arcs': 'gas_arcs', 'nodes':'gas_arcs_vertices_pgr', 'cust': 'gas_cust', 'station_id':539},
'heating': {'arcs':'heat_arcs', 'nodes': 'heat_arcs_vertices_pgr', 'cust': 'heat_cust', 'station_id': 2},
'water': {'arcs': 'vatten_arc', 'nodes':'vatten_arc_vertices_pgr', 'cust': 'vatten_cust', 'station_id':1394}}

app = Flask(__name__)
@app.route('/cust/<filename>')
def custGetter(filename):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg ) as f ) as fc;".format(filename)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar)

@app.route('/arc/<filename>')
def arcGetter(filename):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg ) as f ) as fc;".format(filename)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar)

@app.route('/node/<filename>')
def nodeGetter(filename):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg ) as f ) as fc;".format(filename)
    ##^fix so it gets the correct nodes
    print(filename)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar)

@app.route('/broken/<network_name>/<node_id>')
def nodeBreaker(network_name, node_id):
    arc_tbl = "\'"+tables[network_name]['arcs']+"\'"
    node_tbl = "\'"+tables[network_name]['nodes']+"\'"
    cust_tbl = "\'"+tables[network_name]['cust']+"\'"
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT * FROM nodeMaker({0}, {1}, {2}) WHERE nodemaker IS NOT NULL".format(node_id, arc_tbl, tables[network_name]['station_id'])
    curs.execute(query)
    brokenNodes = [w[0][0] for w in curs.fetchall()]
    print(brokenNodes)
    conn.close()
    nodeSet = set()
    for i in brokenNodes:
        nodeSet = nodeSet.union(bfs(arc_tbl,int(node_id), i))
    conn.close()
    if nodeSet:
        return json.dumps({'Arc':json.loads(getBrokenArc(arc_tbl, nodeSet)),'Node':json.loads(getBrokenNode(node_tbl, nodeSet)),'Cust':json.loads(getBrokenCust(cust_tbl, nodeSet))})
    else:
        return "NULL"    

def bfs(network_name,broken_node, node_id):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    visited, queue = set([broken_node]), [node_id]
    while queue:
        vertex = queue.pop(0)
        if vertex not in visited:
            query = "SELECT * FROM neighbornodes({0}, {1})".format(vertex, network_name) ##Fix dynamic network
            curs.execute(query)
            node_set = set([w[0] for w in curs.fetchall()])
            visited.add(vertex)
            queue.extend(node_set - visited)
    conn.close()
    return visited

def getBrokenArc(network_name,nodeSet):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    print(nodeSet, 'nodes')
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg WHERE source in {1} AND target in {1}) as f ) as fc;".format(network_name.strip("\'"), str(nodeSet).replace('{','(').replace('}',')'))
    print(query)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar)    
    #Gets arcs with source/target in bfs-set



def getBrokenNode(network_name,nodeSet):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg WHERE gid in {1} ) as f ) as fc;".format(network_name.strip("\'"), str(nodeSet).replace('{','(').replace('}',')'))
    print(query)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar) 
    #gets nodes intersecting bfs-set

def getBrokenCust(network_name,nodeSet):
    conn = psycopg2.connect(dbname='postgres', user='postgres', password='digpro', host='')
    curs = conn.cursor()
    query = "SELECT row_to_json(fc) FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) as features FROM (SELECT 'Feature' as type, ST_AsGeoJSON(lg.the_geom)::json As geometry, row_to_json((SELECT l FROM (SELECT dp_otype, dp_ctype, dp_subtype, gid) as l )) as properties FROM {0} as lg WHERE gid in {1}) as f ) as fc;".format(network_name.strip("\'"), str(nodeSet).replace('{','(').replace('}',')'))
    print(query)
    curs.execute(query)
    inVar = (curs.fetchone()[0])
    conn.close()
    return json.dumps(inVar) 
    #gets customers intersecting bfs-set
    

#Jobba med alla nodes, gör två SQL-queries av det sen.

if __name__ == "__main__":
    app.debug = True
    app.run(host='127.0.0.1', port=5000)
